La plupart des navigateurs ne sont pas capables d'afficher une image de largeur supérieure à 32 767 pixels.

L'image que ce zip contient en mesure 40 000, certains de vos logiciels ne pourront peut-être pas l'afficher non plus.

Réalisé par Licoti pour omnilogie.fr